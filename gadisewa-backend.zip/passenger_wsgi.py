import sys, os

# Add the backend directory to sys.path
sys.path.insert(0, os.path.dirname(__file__))

from main import app

# For Phusion Passenger (used by Babal Host/cPanel)
# We need an 'application' object
# application = app

# Wrap FastAPI (ASGI) for WSGI using a2wsgi:
from a2wsgi import ASGIMiddleware
application = ASGIMiddleware(app)
